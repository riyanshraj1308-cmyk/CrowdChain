module.exports = {
  preset: "ts-jest",
  testEnvironment: "node",
  rootDir: ".",
  testMatch: ["<rootDir>/test/api/**/*.test.ts"],
  setupFiles: ["<rootDir>/test/api/setupEnv.ts"],
};
