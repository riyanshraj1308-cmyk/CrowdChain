jest.mock("../../src/config/database", () => ({
  prisma: {
    campaign: { findUnique: jest.fn(), update: jest.fn() },
    contribution: { findUnique: jest.fn(), create: jest.fn(), findMany: jest.fn() },
    user: { upsert: jest.fn() },
    transaction: { create: jest.fn() },
    $transaction: jest.fn(),
  },
}));

jest.mock("../../src/blockchain/blockchainService", () => ({
  verifyTransactionEvent: jest.fn(),
}));

import { prisma } from "../../src/config/database";
import { verifyTransactionEvent } from "../../src/blockchain/blockchainService";
import { recordContribution } from "../../src/services/contribution.service";
import { ApiError } from "../../src/utils/apiResponse";

describe("Contribution service - on-chain verification", () => {
  afterEach(() => jest.clearAllMocks());

  it("rejects recording a contribution when the campaign does not exist", async () => {
    (prisma.campaign.findUnique as jest.Mock).mockResolvedValue(null);
    await expect(
      recordContribution("campaign-1", "0xabc", `0x${"1".repeat(64)}`)
    ).rejects.toThrow(ApiError);
  });

  it("rejects a tx hash that has already been recorded", async () => {
    (prisma.campaign.findUnique as jest.Mock).mockResolvedValue({ id: "c1", contractCampaignId: 0 });
    (prisma.contribution.findUnique as jest.Mock).mockResolvedValue({ id: "existing" });

    await expect(
      recordContribution("c1", "0xabc", `0x${"1".repeat(64)}`)
    ).rejects.toThrow("already been recorded");
  });

  it("rejects when the on-chain event's campaign id does not match", async () => {
    (prisma.campaign.findUnique as jest.Mock).mockResolvedValue({ id: "c1", contractCampaignId: 5 });
    (prisma.contribution.findUnique as jest.Mock).mockResolvedValue(null);
    (verifyTransactionEvent as jest.Mock).mockResolvedValue({
      args: { campaignId: 0, contributor: "0xabc", amount: BigInt(100) },
      blockNumber: 10,
      timestamp: 1000,
      logIndex: 0,
    });

    await expect(
      recordContribution("c1", "0xabc", `0x${"1".repeat(64)}`)
    ).rejects.toThrow("does not correspond to this campaign");
  });

  it("rejects when the tx sender does not match the authenticated wallet", async () => {
    (prisma.campaign.findUnique as jest.Mock).mockResolvedValue({ id: "c1", contractCampaignId: 0 });
    (prisma.contribution.findUnique as jest.Mock).mockResolvedValue(null);
    (verifyTransactionEvent as jest.Mock).mockResolvedValue({
      args: { campaignId: 0, contributor: "0xdifferent", amount: BigInt(100) },
      blockNumber: 10,
      timestamp: 1000,
      logIndex: 0,
    });

    await expect(
      recordContribution("c1", "0xabc", `0x${"1".repeat(64)}`)
    ).rejects.toThrow("does not match authenticated wallet");
  });

  it("records the contribution once verified successfully", async () => {
    (prisma.campaign.findUnique as jest.Mock).mockResolvedValue({ id: "c1", contractCampaignId: 0 });
    (prisma.contribution.findUnique as jest.Mock).mockResolvedValue(null);
    (verifyTransactionEvent as jest.Mock).mockResolvedValue({
      args: { campaignId: 0, contributor: "0xabc", amount: BigInt(1000) },
      blockNumber: 10,
      timestamp: 1000,
      logIndex: 0,
    });
    (prisma.user.upsert as jest.Mock).mockResolvedValue({ id: "user-1" });
    (prisma.$transaction as jest.Mock).mockResolvedValue([{ id: "contribution-1" }]);

    const result = await recordContribution("c1", "0xabc", `0x${"1".repeat(64)}`);
    expect(result).toEqual({ id: "contribution-1" });
    expect(prisma.$transaction).toHaveBeenCalled();
  });
});
