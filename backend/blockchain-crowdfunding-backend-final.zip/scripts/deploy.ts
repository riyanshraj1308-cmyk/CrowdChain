import { ethers, network } from "hardhat";
import * as fs from "fs";
import * as path from "path";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log(`Deploying Crowdfunding contract with account: ${deployer.address}`);
  console.log(`Network: ${network.name} (chainId ${network.config.chainId})`);

  const Crowdfunding = await ethers.getContractFactory("Crowdfunding");
  const crowdfunding = await Crowdfunding.deploy();
  await crowdfunding.waitForDeployment();

  const address = await crowdfunding.getAddress();
  console.log(`Crowdfunding deployed to: ${address}`);

  // Persist deployment info so the backend can pick up the address + ABI automatically.
  const artifact = await import(
    path.join(__dirname, "..", "artifacts", "contracts", "Crowdfunding.sol", "Crowdfunding.json")
  );

  const deploymentInfo = {
    network: network.name,
    chainId: network.config.chainId,
    address,
    deployerAddress: deployer.address,
    deployedAt: new Date().toISOString(),
    abi: artifact.abi,
  };

  const outDir = path.join(__dirname, "..", "src", "blockchain", "contracts");
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(
    path.join(outDir, `Crowdfunding.${network.name}.json`),
    JSON.stringify(deploymentInfo, null, 2)
  );
  // Also write a "latest" pointer used by the backend in local dev.
  fs.writeFileSync(
    path.join(outDir, "Crowdfunding.latest.json"),
    JSON.stringify(deploymentInfo, null, 2)
  );

  console.log(`Deployment info written to src/blockchain/contracts/Crowdfunding.${network.name}.json`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
