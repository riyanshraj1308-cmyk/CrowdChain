import { HardhatUserConfig } from "hardhat/config";
// Granular Hardhat plugins are used instead of the monolithic
// @nomicfoundation/hardhat-toolbox. The toolbox bundles hardhat-ignition,
// hardhat-verify, hardhat-gas-reporter, solidity-coverage, and typechain/hardhat
// — none of which this project uses — and those plugins pull in a large,
// frequently-flagged legacy dependency chain (old ethers v5 + @ethersproject/*,
// elliptic, bn.js, web3-utils, mocha's own diff/serialize-javascript, lodash via
// ignition-core). Importing only what's actually used keeps `npm audit` clean
// without needing the Hardhat 2 -> 3 major upgrade. See package.json's
// "overrides" block and the README's "Dependency security" section for the
// full rationale.
import "@nomicfoundation/hardhat-ethers";
import "@nomicfoundation/hardhat-chai-matchers";
import "@nomicfoundation/hardhat-network-helpers";
import "@typechain/hardhat";
import * as dotenv from "dotenv";

dotenv.config();

const SEPOLIA_RPC_URL = process.env.SEPOLIA_RPC_URL || "";
const DEPLOYER_PRIVATE_KEY = process.env.DEPLOYER_PRIVATE_KEY || "";

const config: HardhatUserConfig = {
  solidity: {
    version: "0.8.24",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
    },
  },
  networks: {
    hardhat: {
      chainId: 31337,
    },
    localhost: {
      url: "http://127.0.0.1:8545",
      chainId: 31337,
    },
    sepolia: {
      url: SEPOLIA_RPC_URL,
      accounts: DEPLOYER_PRIVATE_KEY ? [DEPLOYER_PRIVATE_KEY] : [],
      chainId: 11155111,
    },
  },
  paths: {
    sources: "./contracts",
    tests: "./test/contract",
    cache: "./cache",
    artifacts: "./artifacts",
  },
};

export default config;
