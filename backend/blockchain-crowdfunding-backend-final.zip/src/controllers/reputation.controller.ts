import { Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { success, ApiError } from "../utils/apiResponse";
import { getReputation } from "../services/reputation.service";
import { prisma } from "../config/database";

export const getReputationByAddress = asyncHandler(async (req, res: Response) => {
  const user = await prisma.user.findUnique({
    where: { walletAddress: req.params.address.toLowerCase() },
  });
  if (!user) {
    throw new ApiError(404, "User not found");
  }
  const reputation = await getReputation(user.id);
  return success(res, reputation ?? { score: 0 }, "Reputation fetched");
});
