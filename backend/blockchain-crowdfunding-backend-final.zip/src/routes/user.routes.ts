import { Router } from "express";
import { getReputationByAddress } from "../controllers/reputation.controller";
import { userContributionRouter } from "./contribution.routes";
import { walletAddressParamSchema } from "../validators/contribution.validator";
import { validate } from "../middleware/validate.middleware";

const router = Router();

router.use("/", userContributionRouter);
router.get("/:address/reputation", validate(walletAddressParamSchema), getReputationByAddress);

export default router;
