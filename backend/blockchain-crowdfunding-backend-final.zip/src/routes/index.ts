import { Router } from "express";
import authRoutes from "./auth.routes";
import campaignRoutes from "./campaign.routes";
import userRoutes from "./user.routes";
import { campaignContributionRouter } from "./contribution.routes";
import { milestoneRouter } from "./milestone.routes";

const router = Router();

router.use("/auth", authRoutes);
router.use("/campaigns", campaignRoutes);
router.use("/campaigns", campaignContributionRouter);
router.use("/campaigns", milestoneRouter);
router.use("/users", userRoutes);

export default router;
