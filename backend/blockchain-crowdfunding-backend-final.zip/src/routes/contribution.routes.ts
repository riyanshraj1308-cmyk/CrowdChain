import { Router } from "express";
import {
  recordContribution,
  listContributors,
  listUserContributions,
} from "../controllers/contribution.controller";
import { validate } from "../middleware/validate.middleware";
import {
  recordContributionSchema,
  walletAddressParamSchema,
} from "../validators/contribution.validator";
import { campaignIdParamSchema } from "../validators/campaign.validator";
import { requireAuth } from "../middleware/auth.middleware";

// Mounted at /api/campaigns
export const campaignContributionRouter = Router({ mergeParams: true });

campaignContributionRouter.post(
  "/:id/contribute",
  requireAuth,
  validate(recordContributionSchema),
  recordContribution
);
campaignContributionRouter.get(
  "/:id/contributors",
  validate(campaignIdParamSchema),
  listContributors
);

// Mounted at /api/users
export const userContributionRouter = Router({ mergeParams: true });

userContributionRouter.get(
  "/:address/contributions",
  validate(walletAddressParamSchema),
  listUserContributions
);
