import { Router } from "express";
import { requestNonce, verifySignature, getMe } from "../controllers/auth.controller";
import { validate } from "../middleware/validate.middleware";
import { nonceRequestSchema, verifySignatureSchema } from "../validators/auth.validator";
import { requireAuth } from "../middleware/auth.middleware";
import { authRateLimiter } from "../middleware/rateLimit.middleware";

const router = Router();

router.post("/nonce", authRateLimiter, validate(nonceRequestSchema), requestNonce);
router.post("/verify", authRateLimiter, validate(verifySignatureSchema), verifySignature);
router.get("/me", requireAuth, getMe);

export default router;
